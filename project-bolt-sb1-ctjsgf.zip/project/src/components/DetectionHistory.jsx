import React, { useState, useEffect } from 'react';
import { socket } from '../services/socket';

function DetectionHistory() {
  const [detections, setDetections] = useState([]);

  useEffect(() => {
    socket.on('detection-update', (newDetections) => {
      setDetections(newDetections);
    });

    return () => {
      socket.off('detection-update');
    };
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <h2 className="text-xl font-semibold mb-4">Detection Results</h2>
      <div className="space-y-2">
        {detections.map((detection, index) => (
          <div
            key={index}
            className="p-3 bg-gray-50 rounded-md"
          >
            <p className="font-medium">
              {detection.class} ({Math.round(detection.score * 100)}% confidence)
            </p>
          </div>
        ))}
        {detections.length === 0 && (
          <p className="text-gray-500">No objects detected yet</p>
        )}
      </div>
    </div>
  );
}

export default DetectionHistory;