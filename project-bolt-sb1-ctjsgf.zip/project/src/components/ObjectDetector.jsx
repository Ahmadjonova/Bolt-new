import React, { useRef, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import * as tf from '@tensorflow/tfjs';
import * as cocossd from '@tensorflow-models/coco-ssd';
import { socket } from '../services/socket';
import { drawDetections } from '../utils/drawing';

function ObjectDetector() {
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const [model, setModel] = useState(null);
  const [isDetecting, setIsDetecting] = useState(false);

  useEffect(() => {
    // Load COCO-SSD model
    const loadModel = async () => {
      const loadedModel = await cocossd.load();
      setModel(loadedModel);
      console.log('Model loaded');
    };
    loadModel();
  }, []);

  const detect = async () => {
    if (!model || !webcamRef.current || !webcamRef.current.video) return;

    const video = webcamRef.current.video;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    // Set canvas dimensions
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Make detection
    const predictions = await model.detect(video);

    // Draw results
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.drawImage(video, 0, 0, ctx.canvas.width, ctx.canvas.height);
    drawDetections(predictions, ctx);

    // Send results to server
    socket.emit('detection-result', predictions);

    if (isDetecting) {
      requestAnimationFrame(detect);
    }
  };

  const toggleDetection = () => {
    setIsDetecting(!isDetecting);
  };

  useEffect(() => {
    if (isDetecting) {
      detect();
    }
  }, [isDetecting]);

  return (
    <div className="relative">
      <div className="rounded-lg overflow-hidden shadow-lg">
        <Webcam
          ref={webcamRef}
          muted={true}
          className="w-full"
        />
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 w-full h-full"
        />
      </div>
      <div className="mt-4 flex justify-center">
        <button
          onClick={toggleDetection}
          className={`px-6 py-2 rounded-full font-semibold ${
            isDetecting
              ? 'bg-red-500 hover:bg-red-600'
              : 'bg-green-500 hover:bg-green-600'
          } text-white transition-colors`}
        >
          {isDetecting ? 'Stop Detection' : 'Start Detection'}
        </button>
      </div>
    </div>
  );
}

export default ObjectDetector;