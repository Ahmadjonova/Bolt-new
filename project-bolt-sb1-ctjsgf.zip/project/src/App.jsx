import React from 'react';
import ObjectDetector from './components/ObjectDetector';
import DetectionHistory from './components/DetectionHistory';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-600 text-white p-4">
        <h1 className="text-2xl font-bold text-center">Object Detection Scanner</h1>
      </header>
      
      <main className="container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ObjectDetector />
          <DetectionHistory />
        </div>
      </main>
    </div>
  );
}

export default App;