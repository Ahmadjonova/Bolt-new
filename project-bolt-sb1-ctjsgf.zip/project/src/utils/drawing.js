export const drawDetections = (predictions, ctx) => {
  predictions.forEach(prediction => {
    // Get prediction results
    const [x, y, width, height] = prediction.bbox;
    const text = `${prediction.class} ${Math.round(prediction.score * 100)}%`;

    // Set styling
    ctx.strokeStyle = '#00FF00';
    ctx.lineWidth = 2;
    ctx.fillStyle = '#00FF00';
    ctx.font = '18px Arial';

    // Draw bounding box
    ctx.beginPath();
    ctx.rect(x, y, width, height);
    ctx.stroke();

    // Draw label background
    const textWidth = ctx.measureText(text).width;
    ctx.fillStyle = '#00FF00';
    ctx.fillRect(x, y - 25, textWidth + 10, 25);

    // Draw label text
    ctx.fillStyle = '#000000';
    ctx.fillText(text, x + 5, y - 7);
  });
};